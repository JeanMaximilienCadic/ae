from .functional import *
from gnutools.utils import load_yaml
cfg = load_yaml("config.yml")
__version__="0.1.0"